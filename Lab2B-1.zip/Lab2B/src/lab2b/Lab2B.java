/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package lab2b;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.Paths;
import java.util.Formatter;
import java.util.NoSuchElementException;
import java.util.Scanner;

/**
 *
 * Name: Nelson Contreras
 * Class: CMSY-167-001: Java 2
 * Brief Description: What this program will do is reading 
 * the file LAB2A.txt and then writing email's that are of HCC
 * to howard.txt, if email is invalid then it will print email
 * Invalid.
 */
public class Lab2B {
  public static void main(String[] args) {
      String email = null;
      String emailHCC = "@howardcc.edu";
      String emailSpecific = "dmilburn@howardcc.edu";
      int charPos = 0;
      int emailLength;
      // open Lab2A.txt, read its contents and close the file
      //Formatter output = new Formatter("howard.txt");
      
      try(Scanner input = new Scanner(Paths.get("Lab2A.txt")); 
              Formatter output = new Formatter("howard.txt");) {

         // read record from file
         while (input.hasNext()) { // while there is more to read
            // display record contents, the email contents.  
            email = input.next();
            email = email.trim();
            email = email.toLowerCase();
            emailLength = email.length();
            charPos = email.indexOf("@");
            
            
            //if character position email index of @
            //does not exist then provide a message saying that
            //particular email is invalid while displaying the 
            //invalid email. 
            if(charPos == -1)
            {
                System.err.println(email + "-Email invalid");
            } 
            else
            { 
                //email = input.next();
                //if email ends with @howardcc.edu
                //then output it to the howard.txt file
                //upper-casing the pastry professors email
                if (email.endsWith(emailHCC))
                {
                    if (email.equalsIgnoreCase(emailSpecific))
                        output.format("%s%n", email.toUpperCase());
                    else
                        output.format("%s%n", email);  
                } 
                System.out.printf("%s%nLength: %s%nCharacters after @: %s%n%n"
                        ,email, email.length(), charPos);
            }
    
            
         }       
      } 
      catch (IOException | NoSuchElementException | 
         IllegalStateException e) {
         e.printStackTrace();
      } 
   }
}

