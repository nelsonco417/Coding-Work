package java2finalproject;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 *
 * Name: Nelson Contreras
 * Class: CMSY-167 Java 2
 * Brief Description: HCC Pastries Inc’s has been very impressed with your work over the last few weeks, 
 * so they are leaving you in charge of the most important part of the company: employee morale.
 * It turns out, HCC Pastries Inc’s attempt at world domination was not very popular with the 
 * rank and file employees. They feel neglected and purposeless. 
 * The company recognizes that, so they’re putting you on the case. 
 * HCC Pastries Inc wants to give their employees a fun diversion, 
 * so they want you to create a word-guessing game reminiscent of Hangman.
 */
public class Java2FinalProject extends Application {
    
    @Override
    public void start(Stage stage) throws Exception {
        Parent root = FXMLLoader.load(getClass().getResource("FXMLDocument.fxml"));
        
        Scene scene = new Scene(root);
        
        stage.setScene(scene);
        stage.show();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
}
