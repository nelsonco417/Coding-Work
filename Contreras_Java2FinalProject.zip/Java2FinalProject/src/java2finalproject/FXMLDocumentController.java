package java2finalproject;

import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.URL;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Random;
import java.util.ResourceBundle;
import java.util.Scanner;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Slider;
import javafx.scene.control.TextField;
import javafx.util.converter.NumberStringConverter;
//import javax.swing.Action;

/**
 *
 * Name: Nelson Contreras
 * Class: CMSY-167 Java 2
 * Brief Description: HCC Pastries Inc’s has been very impressed with your work over the last few weeks, 
 * so they are leaving you in charge of the most important part of the company: employee morale.
 * It turns out, HCC Pastries Inc’s attempt at world domination was not very popular with the 
 * rank and file employees. They feel neglected and purposeless. 
 * The company recognizes that, so they’re putting you on the case. 
 * HCC Pastries Inc wants to give their employees a fun diversion, 
 * so they want you to create a word-guessing game reminiscent of Hangman.
 */
public class FXMLDocumentController implements Initializable {
    
    String mysWord = "";
    String allGuessedLetters = "";
    String wordsRead = "";
    private int lettersLEFT = 0;
    List<String> Length6 = new ArrayList<String>();
    List<String> Length8 = new ArrayList<String>();
    List<String> Length10 = new ArrayList<String>();
    
    @FXML
    private Slider DiffSlider;

    @FXML
    private Button GenButton;

    @FXML
    private Label GuessRemainsLabel;

    @FXML
    private Label LetGuessLabel;

    @FXML
    private Label GuessLabel;
    
    @FXML
    private Label wordStat;
    
    @FXML
    private Label hangmanWordLabel;
    
    @FXML
    private Label difficultLevel;
    
    @FXML
    private Label wordDifficultLevel;

    @FXML
    private TextField guessTextfield;
    
    @FXML
    private Label letterGuess;
    
    @FXML
    private Label guessR;

    @FXML
    private Button GuessBtn;

    @FXML
    private Button SaveBtn;

    @FXML
    private Button GiveUpBtn;

    @FXML
    private Button LoadBtn;
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        SaveBtn.setVisible(false);
        GiveUpBtn.setVisible(false);
        wordStat.setVisible(false);
        GuessBtn.setVisible(false);
        guessTextfield.setVisible(false);
        hangmanWordLabel.setVisible(false);
        guessR.setVisible(false);
        GuessRemainsLabel.setVisible(false);
        LetGuessLabel.setVisible(false);
        GuessLabel.setVisible(false);
        slider();
    }

    @FXML
    void GenerateButtonClick(ActionEvent event) {
        show();
        LoadBtn.setVisible(true);
        wordStat.setText("");
        letterGuess.setText("");

        ReadingTheFile();
        go();

        //trying to figure out how to generate words;
        String word = generateWord();

        hangmanStat(word);
        mysWord = word;

        double numSlider = DiffSlider.valueProperty().doubleValue();
        if (numSlider < 49) {
            lettersLEFT = 10;
        } else if (numSlider < 99) {
            lettersLEFT = 7;
        } else {
            lettersLEFT = 4;
        }

        guessR.setText(String.valueOf(lettersLEFT));
    }

    @FXML
    void GiveUpButtonAction(ActionEvent event) {
        stop();
        GenButton.setDisable(false);
        DiffSlider.setDisable(false);
        wordStat.setText("Don't Give Up, The word was: " + mysWord);
    }

    @FXML
    void GuessButtonAction(ActionEvent event) {
        String hangmanText = hangmanWordLabel.getText().replace(" ", "");
        String guessedText = letterGuess.getText();
        String guessLetter = guessTextfield.getText();
        String aNewWord = "";

        wordStat.setText("");

        if (lettersLEFT <= 0) {
            return;
        } // end of if

        char[] wordArray = mysWord.toCharArray();

        if (mysWord.contains(guessLetter)) {
            if (!hangmanText.contains(guessLetter)) {
                for (int count = 0; count < wordArray.length; count++) 
                {
                    if (String.valueOf(wordArray[count]).contains(guessLetter)) {
                        aNewWord += guessLetter + "  ";

                    } else {
                        aNewWord += hangmanText.substring(count, count + 1) + "  ";
                    } // end of else
                } // end of for loop
                hangmanWordLabel.setText(aNewWord);
            } // end of if
        } else {
            lettersLEFT--;
        } 

        guessR.setText(String.valueOf(lettersLEFT));

        if (!guessedText.contains(guessLetter))
        {
            //then put the information into the letterGuess field
            //adding a comma after each letter that has been guessed.
            guessedText = guessedText + guessLetter;
            letterGuess.setText(guessedText + ", ");
        } // end of if
        guessTextfield.requestFocus();
        guessTextfield.setText("");
        GenButton.setDisable(true);
        DiffSlider.setDisable(true);

        if (lettersLEFT <= 0) {
            wordStat.setText("You LOST! The word was: " + mysWord);
            stop();
            GenButton.setDisable(false);
            DiffSlider.setDisable(false);

        } else if (mysWord.equalsIgnoreCase(aNewWord.replace(" ", ""))) {
            wordStat.setText("You Won! The word was: " + mysWord + " You nailed it!");
            stop();
            GenButton.setDisable(false);
            DiffSlider.setDisable(false);
        } 

    }

    @FXML
    void LoadButtonAction(ActionEvent event) throws IOException, ClassNotFoundException{
    HangmanGame hangmanGame = null;
    FileInputStream fileStream = new FileInputStream("createHangman.obj");   
    ObjectInputStream objectStream = new ObjectInputStream(fileStream);   

    hangmanGame = (HangmanGame) objectStream.readObject();
    
    wordStat.setText("Game loaded! BOOYAH");
    
    gameState(hangmanGame);
    letterGuess.setVisible(true);
    DiffSlider.setVisible(true);
    fileStream.close();
    objectStream.close();
      
    }

    @FXML
    void SaveButtonAction(ActionEvent event) throws FileNotFoundException, IOException {
    HangmanGame hangmanGame = new HangmanGame(mysWord, hangmanWordLabel.getText(), letterGuess.getText(), 
                lettersLEFT, wordDifficultLevel.getText(), DiffSlider.valueProperty().doubleValue());
    
        FileOutputStream fileStream = new FileOutputStream("createHangman.obj");   
        ObjectOutputStream objectStream = new ObjectOutputStream(fileStream);   

        objectStream.writeObject(hangmanGame);  

        objectStream.close();   
        fileStream.close();   
        
        wordStat.setText("Game SAVED! Don't Worry!");
        stop();
        GenButton.setDisable(false);
        DiffSlider.setDisable(false);
        LoadBtn.setDisable(false);
    }

    @FXML
    void guessTextfieldAction(ActionEvent event) {

    }
    private void ReadingTheFile()
    {
     try(Scanner read = new Scanner(Paths.get("hangmanWords.txt"));) 
     {      
      while(read.hasNext())
      {
          wordsRead = read.next();
          switch (wordsRead.length()) 
          {
              case 10:
                  Length10.add(wordsRead);
                  break;
              case 8:
                  Length8.add(wordsRead);
                  break;
              case 6:
                  Length6.add(wordsRead);
                  break;
              default:
                  break;
          }
      }
      read.close();
     } 
      catch (IOException | NoSuchElementException | 
         IllegalStateException e) {
         e.printStackTrace();
     }
    }
    private String generateWord() {
        ArrayList<String> genWords = new ArrayList<>();
        double numSlider = DiffSlider.valueProperty().doubleValue();

        if (numSlider < 49) {
            genWords.addAll(Length10);
        } else if (numSlider < 99) {
            genWords.addAll(Length8);
        } else {
            genWords.addAll(Length6);
        }
        
        //creating a random generator for the words
        Random rand = new Random();
        int randomWords = rand.nextInt(genWords.size());

        String newWord = "";
        newWord = genWords.get(randomWords);
      System.out.println("Word: " + newWord);
        return newWord;
    } 
    private void hangmanStat(String word) 
    {
        String wordHang = "";
        int countW = word.length();
        for (int i = 0; i < countW; i++) 
        {
            wordHang = wordHang + "_  ";
        }
        hangmanWordLabel.setText(wordHang);

    } // end of hangman.
    private void slider()
    {
    
    DiffSlider.valueProperty().addListener(new ChangeListener<Number>() {
    @Override
    public void changed(ObservableValue<? extends Number> observable,
            Number oldValue, Number newValue) {
        
        double numSlide = DiffSlider.valueProperty().doubleValue();
        
        if (numSlide < 49)
        {
            wordDifficultLevel.setText("Level: Easy");
        }
        else if (numSlide < 99)
        {
            wordDifficultLevel.setText("Level: Medium");
        }
        else
        {
            wordDifficultLevel.setText("Level: Hard");
        }
          
    }
    });
    }
    private void gameState(HangmanGame hangmanGame)
    {
        go();
        show();
        this.mysWord = hangmanGame.getTheWord();
        letterGuess.setText(hangmanGame.getLettersGuess());
        hangmanWordLabel.setText(hangmanGame.getHangmanLabel());
        DiffSlider.valueProperty().set(hangmanGame.getSlider());
        lettersLEFT = hangmanGame.getLettersRemaining();
        guessR.setText(String.valueOf(lettersLEFT));
    }
    private void show()
    {
        SaveBtn.setVisible(true);
        GiveUpBtn.setVisible(true);
        wordStat.setVisible(true);
        GuessBtn.setVisible(true);
        guessTextfield.setVisible(true);
        hangmanWordLabel.setVisible(true);
        GuessRemainsLabel.setVisible(true);
        guessR.setVisible(true);
        LetGuessLabel.setVisible(true);
        GuessLabel.setVisible(true);
    }
    private void go()
    {
        SaveBtn.setDisable(false);
        GiveUpBtn.setDisable(false);
        GuessBtn.setDisable(false);
        LoadBtn.setDisable(false);
        GuessRemainsLabel.setDisable(false);
        LetGuessLabel.setDisable(false);
        guessR.setDisable(false);
        letterGuess.setDisable(false);
        guessTextfield.setDisable(false);
        GuessLabel.setDisable(false);
        hangmanWordLabel.setDisable(false);
        GenButton.setDisable(false);
        DiffSlider.setDisable(false);
    }
    private void stop()
    {
        SaveBtn.setDisable(true);
        GiveUpBtn.setDisable(true);
        GuessBtn.setDisable(true);
        LoadBtn.setDisable(true);
        GuessRemainsLabel.setDisable(true);
        LetGuessLabel.setDisable(true);
        guessR.setDisable(true);
        letterGuess.setDisable(true);
        guessTextfield.setDisable(true);
        GuessLabel.setDisable(true);
        hangmanWordLabel.setDisable(true);
    }
    
}
