package java2finalproject;

import java.io.Serializable;

public class HangmanGame implements Serializable {

    private String mysWord;
    private String guessTextfield;
    private String wordStat;
    private String GuessRemainsLabel;
    private String LetGuessLabel;
    private int lettersLEFT;
    private String guessLabel;
    private String lettersGuess;
    private String hangmanWordLabel;
    private String difficultLevel;
    private String gameStatus;
    private String wordDifficultLevel;
    private double DiffSlider;

    public HangmanGame(String mysWord, String hangmanWordLabel, String lettersGuess,
            int lettersLEFT, String wordDifficultLevel, double DiffSlider) {

        this.mysWord = mysWord;
        this.hangmanWordLabel = hangmanWordLabel;
        this.lettersGuess = lettersGuess;
        this.lettersLEFT = lettersLEFT;
        this.wordDifficultLevel = wordDifficultLevel;
        this.DiffSlider = DiffSlider;
    } // end of constructor

    public String getGuess() {
        return this.guessTextfield;
    } // end of getter

    public String getHangmanLabel() {
        return this.hangmanWordLabel;
    } // end of getter

    public String getGuessRemainingLabel() {
        return this.GuessRemainsLabel;
    } // end of getter

    public String getLettersGuess() {
        return this.guessLabel;
    } // end of getter

    public int getLettersRemaining() {
        return this.lettersLEFT;
    } // end of getter

    public String getLettersGuessedLabel() {
        return this.LetGuessLabel;
    } // end of getter

    public String getGuessLabel() {
        return this.guessLabel;
    } // end of getter

    public String getWordStatus() {
        return this.wordStat;
    } // end of getter

    public String getDifficultLevel() {
        return this.difficultLevel;
    }

    public String getgameStatus() {
        return this.gameStatus;
    } // end of getter

    public String getWordDifficultLevel() {
        return this.wordDifficultLevel;
    } // end of getter

    public double getSlider() {
        return this.DiffSlider;
    } // end of getter

    public String getTheWord() {
        return this.mysWord;
    } // end of getter

} // end of hangman game class

