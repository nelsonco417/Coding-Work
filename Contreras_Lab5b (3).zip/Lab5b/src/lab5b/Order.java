package lab5b;
public class Order {
    private String customerName;
    private String address;
    private double poundPastries;
    
    public Order(String customerName, String address, double poundPastries)
    {
        this.customerName = customerName;
        this.address = address;
        this.poundPastries = poundPastries;
    }
    public Order()
    {
       customerName = "";
       address = "";
       poundPastries = 0.0;
    }
    public void setCustomerName(String customerName)
    {
        this.customerName = customerName;
    }
    public void setAddress(String address)
    {
        this.address = address;
    }
    public void setPoundPastries(double poundPastries)
    {
        this.poundPastries = poundPastries;
    }
    public String getCustomerName()
    {
        return customerName;
    }
    public String getAddress()
    {
        return address;
    }
    public double getPoundPastries()
    {
        return poundPastries;
    }
    
    //only used for testing purposes
    @Override
    public String toString()
    {
        return customerName + " " + address + " " + poundPastries;
    } 
}
