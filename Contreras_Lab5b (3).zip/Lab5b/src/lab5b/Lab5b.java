package lab5b;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

/**
 *
 * Nelson Contreras
 * Class: CMSY-167 Java 2
 * Assignment: Lab5b
 * Brief Description: This program is used for a large
 * demand of products to be shipped all over the country.
 * The API is acting very slow and we must use concurrency
 * so that the program can be making several calls to the API
 * at one time. also calculate how much money is being spent 
 * on shipping. 
 */
public class Lab5b {
    
    public static double totalCosts = 0;
    
    public static void main(String[] args) throws InterruptedException {
        
        //creates a ExecutorService to manage threads
        ExecutorService executorService = Executors.newCachedThreadPool();
         
        //creating a list to hold incoming orders
        List<Order> myList = new ArrayList<>();
        Order o[] = new Order[6];
        
        o[0] = new Order(" Josue Aventura", " 6121 Main St. Brentwood,NY", 12);
        o[1] = new Order(" Willy Wonka", " 12 Tally Tall Rd. Lanham,MD", 24);
        o[2] = new Order(" Peter Griffin", " 31 Spooner St. Quahog,CA", 76);
        o[3] = new Order(" Jerry Seinfeld", " Apartment 5A, 129 West 81st St. Ontario,CA", 14);
        o[4] = new Order(" Donald Duck", " 1313 Webfoot Walk St. Riverside, CA", 4);
        o[5] = new Order(" The Jetsons", " 417 Skypad Aparments, 123 Lala Ave. Mexico City,MX", 8);
        
        List<Order> orderList = Arrays.asList(o);
        myList.addAll(orderList);
        
        System.out.println("Here is the HCC Pastries Shipping Service!!!");
        System.out.println();
            
        PrintTask orderTask1 = new PrintTask(myList.get(0));
        PrintTask orderTask2 = new PrintTask(myList.get(1));
        PrintTask orderTask3 = new PrintTask(myList.get(2));
        PrintTask orderTask4 = new PrintTask(myList.get(3));
        PrintTask orderTask5 = new PrintTask(myList.get(4));
        PrintTask orderTask6 = new PrintTask(myList.get(5));
        
        executorService.execute(orderTask1);
        executorService.execute(orderTask2);
        executorService.execute(orderTask3);
        executorService.execute(orderTask4);
        executorService.execute(orderTask5);
        executorService.execute(orderTask6);
        
        
        //shut down executorService -- it decides when to shut down threads.
        executorService.shutdown();
        
        while(!executorService.awaitTermination(60, TimeUnit.SECONDS)){}
        
        System.out.println();
        System.out.println("Total cost of all Shipments: (in cents) " + totalCosts);
    }
}
    
