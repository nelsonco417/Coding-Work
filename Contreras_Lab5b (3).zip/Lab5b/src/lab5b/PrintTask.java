package lab5b;

import java.security.SecureRandom;
import java.util.List;
import static lab5b.Lab5b.totalCosts;

public class PrintTask implements Runnable {
   private static final SecureRandom generator = new SecureRandom();
   private final int sleepTime; // random sleep time for thread
   //private final String taskName; 
   private final String recipientName;
   private final String destA;
   private final double weightInPounds;
    
   // constructor
   public PrintTask(String recipientName, String destA, double weightInPounds) {
      this.recipientName = recipientName;
      this.destA = destA;
      this.weightInPounds = weightInPounds;
        
      sleepTime = generator.nextInt(10000); 
   }
   public PrintTask(Order order) {
       this.recipientName = order.getCustomerName();
       this.destA = order.getAddress();
       this.weightInPounds = order.getPoundPastries();
       
       sleepTime = generator.nextInt(5000); 
   }
   
   @Override
   public void run() {
      synchronized(this){
      ShippingLabel ORDERlabel = new ShippingService().getShippingLabel(recipientName, destA, weightInPounds);
      
      //keeping track of totalcost
      totalCosts += ORDERlabel.getCostInCents();
      
      System.out.println("\n\t\t---Postage Label--- \nRecipient Name: " + ORDERlabel.getRecipientName() + ""
              + "\nDestination Address: " + ORDERlabel.getDestinationAddress() + "\nWeight in Pounds: "
      + ORDERlabel.getWeightInPounds() + "\nTracking Number: " + ORDERlabel.getTrackingNumber()
      + "\nCost in cents: " + ORDERlabel.getCostInCents());   
      
        
      }
   }
    
}
